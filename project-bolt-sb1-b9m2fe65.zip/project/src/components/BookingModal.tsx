import { useState } from 'react';
import { X, Calendar, Users, Mail, User } from 'lucide-react';
import { supabase, Destination, Booking } from '../lib/supabase';

interface BookingModalProps {
  destination: Destination | null;
  onClose: () => void;
}

export default function BookingModal({ destination, onClose }: BookingModalProps) {
  const [formData, setFormData] = useState({
    customer_name: '',
    customer_email: '',
    travel_date: '',
    num_travelers: 1,
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  if (!destination) return null;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    try {
      const booking: Booking = {
        destination_id: destination.id,
        customer_name: formData.customer_name,
        customer_email: formData.customer_email,
        travel_date: formData.travel_date,
        num_travelers: formData.num_travelers,
      };

      const { error } = await supabase.from('bookings').insert([booking]);

      if (error) throw error;

      setSuccess(true);
      setTimeout(() => {
        onClose();
        setSuccess(false);
        setFormData({
          customer_name: '',
          customer_email: '',
          travel_date: '',
          num_travelers: 1,
        });
      }, 2000);
    } catch (error) {
      console.error('Error creating booking:', error);
      alert('Failed to create booking. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  const minDate = new Date().toISOString().split('T')[0];

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="relative">
          <img
            src={destination.image_url}
            alt={destination.name}
            className="w-full h-48 object-cover rounded-t-3xl"
          />
          <button
            onClick={onClose}
            className="absolute top-4 right-4 bg-white rounded-full p-2 hover:bg-gray-100 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">
            Book Your Trip to {destination.name}
          </h2>
          <p className="text-gray-600 mb-6">{destination.country}</p>

          {success ? (
            <div className="bg-green-50 border-2 border-green-500 rounded-2xl p-8 text-center">
              <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg
                  className="w-8 h-8 text-white"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M5 13l4 4L19 7"
                  />
                </svg>
              </div>
              <h3 className="text-2xl font-bold text-green-900 mb-2">
                Booking Confirmed!
              </h3>
              <p className="text-green-700">
                We'll send you a confirmation email shortly.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
                  <User className="w-4 h-4" />
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={formData.customer_name}
                  onChange={(e) =>
                    setFormData({ ...formData, customer_name: e.target.value })
                  }
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                  placeholder="John Doe"
                />
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
                  <Mail className="w-4 h-4" />
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={formData.customer_email}
                  onChange={(e) =>
                    setFormData({ ...formData, customer_email: e.target.value })
                  }
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                  placeholder="john@example.com"
                />
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
                  <Calendar className="w-4 h-4" />
                  Travel Date
                </label>
                <input
                  type="date"
                  required
                  min={minDate}
                  value={formData.travel_date}
                  onChange={(e) =>
                    setFormData({ ...formData, travel_date: e.target.value })
                  }
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-2">
                  <Users className="w-4 h-4" />
                  Number of Travelers
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  max="20"
                  value={formData.num_travelers}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      num_travelers: parseInt(e.target.value),
                    })
                  }
                  className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div className="bg-blue-50 rounded-2xl p-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-700">Price per person</span>
                  <span className="text-xl font-bold text-gray-900">
                    ${destination.price}
                  </span>
                </div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-700">Number of travelers</span>
                  <span className="text-xl font-bold text-gray-900">
                    {formData.num_travelers}
                  </span>
                </div>
                <div className="border-t-2 border-blue-200 pt-2 mt-2">
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-semibold text-gray-900">
                      Total Price
                    </span>
                    <span className="text-2xl font-bold text-blue-600">
                      ${destination.price * formData.num_travelers}
                    </span>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-blue-600 text-white py-4 rounded-xl font-semibold text-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
              >
                {loading ? 'Processing...' : 'Confirm Booking'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
