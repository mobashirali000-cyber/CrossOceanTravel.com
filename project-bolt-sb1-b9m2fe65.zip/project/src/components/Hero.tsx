import { Plane } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative h-screen">
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url(https://images.pexels.com/photos/1271619/pexels-photo-1271619.jpeg)',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70"></div>
      </div>

      <div className="relative z-10 h-full flex flex-col items-center justify-center text-white px-4">
        <div className="flex items-center gap-3 mb-6 animate-fade-in">
          <Plane className="w-12 h-12" />
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight">Wanderlust</h1>
        </div>

        <p className="text-xl md:text-2xl text-center max-w-3xl mb-12 font-light leading-relaxed">
          Discover extraordinary destinations and create unforgettable memories around the world
        </p>

        <a
          href="#destinations"
          className="bg-white text-gray-900 px-10 py-4 rounded-full font-semibold text-lg hover:bg-gray-100 transition-all duration-300 transform hover:scale-105 shadow-2xl"
        >
          Explore Destinations
        </a>
      </div>
    </div>
  );
}
