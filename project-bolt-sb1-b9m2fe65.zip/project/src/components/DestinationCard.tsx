import { Star, MapPin } from 'lucide-react';
import { Destination } from '../lib/supabase';

interface DestinationCardProps {
  destination: Destination;
  onBookNow: (destination: Destination) => void;
}

export default function DestinationCard({ destination, onBookNow }: DestinationCardProps) {
  return (
    <div className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
      <div className="relative h-64 overflow-hidden">
        <img
          src={destination.image_url}
          alt={destination.name}
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
        />
        {destination.featured && (
          <div className="absolute top-4 right-4 bg-yellow-400 text-gray-900 px-3 py-1 rounded-full text-sm font-semibold">
            Featured
          </div>
        )}
      </div>

      <div className="p-6">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-1">{destination.name}</h3>
            <div className="flex items-center text-gray-600 gap-1">
              <MapPin className="w-4 h-4" />
              <span className="text-sm">{destination.country}</span>
            </div>
          </div>
          <div className="flex items-center gap-1 bg-yellow-50 px-2 py-1 rounded-lg">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="font-semibold text-gray-900">{destination.rating}</span>
          </div>
        </div>

        <p className="text-gray-600 mb-4 line-clamp-3">{destination.description}</p>

        <div className="flex items-center justify-between">
          <div>
            <span className="text-sm text-gray-500">Starting from</span>
            <p className="text-2xl font-bold text-blue-600">${destination.price}</p>
          </div>
          <button
            onClick={() => onBookNow(destination)}
            className="bg-blue-600 text-white px-6 py-3 rounded-full font-semibold hover:bg-blue-700 transition-colors"
          >
            Book Now
          </button>
        </div>
      </div>
    </div>
  );
}
