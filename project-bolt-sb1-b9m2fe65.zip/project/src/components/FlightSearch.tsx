import { useState } from 'react';
import { Plane } from 'lucide-react';

export default function FlightSearch() {
  const [tripType, setTripType] = useState<'return' | 'oneway'>('return');
  const [formData, setFormData] = useState({
    flyingFrom: '',
    flyingTo: '',
    departureDate: '',
    returnDate: '',
    passengers: '1',
    classOfService: 'economy',
    airlines: '',
    bagOnlyFares: false,
    directFlightsOnly: false,
  });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    console.log('Flight search:', { tripType, ...formData });
    alert('Flight search functionality coming soon!');
  }

  return (
    <div className="bg-white rounded-2xl shadow-2xl p-6 md:p-8 max-w-5xl mx-auto -mt-20 relative z-20">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl md:text-3xl font-bold text-gray-900">FLIGHT SEARCH</h2>
        <span className="text-sm font-semibold text-gray-700">Cross Ocean Travel</span>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="flex gap-6 mb-6">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              name="tripType"
              value="return"
              checked={tripType === 'return'}
              onChange={() => setTripType('return')}
              className="w-4 h-4 accent-green-600"
            />
            <span className="text-gray-900 font-medium">Return</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              name="tripType"
              value="oneway"
              checked={tripType === 'oneway'}
              onChange={() => setTripType('oneway')}
              className="w-4 h-4 accent-green-600"
            />
            <span className="text-gray-900 font-medium">One way</span>
          </label>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
          <div>
            <label className="block text-xs font-bold text-gray-900 mb-2 uppercase">
              Flying From
            </label>
            <input
              type="text"
              placeholder="Departure Airport"
              value={formData.flyingFrom}
              onChange={(e) => setFormData({ ...formData, flyingFrom: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded focus:border-green-600 focus:outline-none text-gray-700"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-900 mb-2 uppercase">
              Flying To
            </label>
            <input
              type="text"
              placeholder="Destination Airport"
              value={formData.flyingTo}
              onChange={(e) => setFormData({ ...formData, flyingTo: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded focus:border-green-600 focus:outline-none text-gray-700"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-900 mb-2 uppercase">
              Departure Date
            </label>
            <input
              type="date"
              value={formData.departureDate}
              onChange={(e) => setFormData({ ...formData, departureDate: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded focus:border-green-600 focus:outline-none text-gray-700"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-900 mb-2 uppercase">
              Return Date
            </label>
            <input
              type="date"
              value={formData.returnDate}
              onChange={(e) => setFormData({ ...formData, returnDate: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded focus:border-green-600 focus:outline-none text-gray-700"
              disabled={tripType === 'oneway'}
              required={tripType === 'return'}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
          <div>
            <label className="block text-xs font-bold text-gray-900 mb-2 uppercase">
              Passengers
            </label>
            <select
              value={formData.passengers}
              onChange={(e) => setFormData({ ...formData, passengers: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded focus:border-green-600 focus:outline-none text-gray-700"
            >
              {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                <option key={num} value={num}>
                  {num}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-900 mb-2 uppercase">
              Class of Service
            </label>
            <select
              value={formData.classOfService}
              onChange={(e) => setFormData({ ...formData, classOfService: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded focus:border-green-600 focus:outline-none text-gray-700"
            >
              <option value="economy">Economy</option>
              <option value="premium-economy">Premium Economy</option>
              <option value="business">Business</option>
              <option value="first">First Class</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-900 mb-2 uppercase">
              Airlines:
            </label>
            <input
              type="text"
              placeholder="Optional"
              value={formData.airlines}
              onChange={(e) => setFormData({ ...formData, airlines: e.target.value })}
              className="w-full px-4 py-3 border border-gray-300 rounded focus:border-green-600 focus:outline-none text-gray-700"
            />
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              className="w-full bg-green-600 text-white py-3 px-6 rounded font-bold uppercase hover:bg-green-700 transition-colors text-sm"
            >
              Search
            </button>
          </div>
        </div>

        <div className="flex gap-6">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.bagOnlyFares}
              onChange={(e) => setFormData({ ...formData, bagOnlyFares: e.target.checked })}
              className="w-4 h-4 accent-green-600"
            />
            <span className="text-gray-700 text-sm">Bag only fares</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={formData.directFlightsOnly}
              onChange={(e) => setFormData({ ...formData, directFlightsOnly: e.target.checked })}
              className="w-4 h-4 accent-green-600"
            />
            <span className="text-gray-700 text-sm">Direct flights only</span>
          </label>
        </div>
      </form>
    </div>
  );
}
