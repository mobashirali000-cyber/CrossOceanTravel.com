import { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import FlightSearch from './components/FlightSearch';
import Destinations from './components/Destinations';
import Testimonials from './components/Testimonials';
import BookingModal from './components/BookingModal';
import Footer from './components/Footer';
import { Destination } from './lib/supabase';

function App() {
  const [selectedDestination, setSelectedDestination] = useState<Destination | null>(null);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <div id="home">
        <Hero />
      </div>
      <div className="px-4 sm:px-6 lg:px-8 pb-20">
        <FlightSearch />
      </div>
      <Destinations onBookNow={setSelectedDestination} />
      <Testimonials />
      <Footer />
      {selectedDestination && (
        <BookingModal
          destination={selectedDestination}
          onClose={() => setSelectedDestination(null)}
        />
      )}
    </div>
  );
}

export default App;
