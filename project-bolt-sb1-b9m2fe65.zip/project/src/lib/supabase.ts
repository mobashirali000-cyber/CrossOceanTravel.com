import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Destination {
  id: string;
  name: string;
  country: string;
  description: string;
  image_url: string;
  price: number;
  rating: number;
  category: string;
  featured: boolean;
  created_at: string;
}

export interface Testimonial {
  id: string;
  customer_name: string;
  destination_id: string;
  rating: number;
  comment: string;
  created_at: string;
}

export interface Booking {
  id?: string;
  destination_id: string;
  customer_name: string;
  customer_email: string;
  travel_date: string;
  num_travelers: number;
  status?: string;
}
