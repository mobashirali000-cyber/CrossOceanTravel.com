/*
  # Travel Website Database Schema

  1. New Tables
    - `destinations`
      - `id` (uuid, primary key) - Unique identifier for each destination
      - `name` (text) - Name of the destination
      - `country` (text) - Country where destination is located
      - `description` (text) - Detailed description of the destination
      - `image_url` (text) - URL to destination image
      - `price` (numeric) - Starting price for packages
      - `rating` (numeric) - Average rating (0-5)
      - `category` (text) - Type of destination (beach, mountain, city, cultural)
      - `featured` (boolean) - Whether destination is featured on homepage
      - `created_at` (timestamptz) - When destination was added
    
    - `bookings`
      - `id` (uuid, primary key) - Unique booking identifier
      - `destination_id` (uuid, foreign key) - Reference to destination
      - `customer_name` (text) - Name of customer
      - `customer_email` (text) - Email of customer
      - `travel_date` (date) - Date of travel
      - `num_travelers` (integer) - Number of travelers
      - `status` (text) - Booking status (pending, confirmed, cancelled)
      - `created_at` (timestamptz) - When booking was created

    - `testimonials`
      - `id` (uuid, primary key) - Unique testimonial identifier
      - `customer_name` (text) - Name of customer
      - `destination_id` (uuid, foreign key) - Reference to destination
      - `rating` (integer) - Rating given (1-5)
      - `comment` (text) - Customer review
      - `created_at` (timestamptz) - When testimonial was created

  2. Security
    - Enable RLS on all tables
    - Public read access for destinations and testimonials
    - Authenticated users can create bookings
    - Public can create bookings (for demo purposes)
*/

-- Create destinations table
CREATE TABLE IF NOT EXISTS destinations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  country text NOT NULL,
  description text NOT NULL,
  image_url text NOT NULL,
  price numeric NOT NULL DEFAULT 0,
  rating numeric NOT NULL DEFAULT 0 CHECK (rating >= 0 AND rating <= 5),
  category text NOT NULL,
  featured boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create bookings table
CREATE TABLE IF NOT EXISTS bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  destination_id uuid REFERENCES destinations(id) ON DELETE CASCADE,
  customer_name text NOT NULL,
  customer_email text NOT NULL,
  travel_date date NOT NULL,
  num_travelers integer NOT NULL DEFAULT 1 CHECK (num_travelers > 0),
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

-- Create testimonials table
CREATE TABLE IF NOT EXISTS testimonials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  destination_id uuid REFERENCES destinations(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE destinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE testimonials ENABLE ROW LEVEL SECURITY;

-- Destinations policies (public read)
CREATE POLICY "Anyone can view destinations"
  ON destinations FOR SELECT
  USING (true);

-- Bookings policies (anyone can create for demo)
CREATE POLICY "Anyone can create bookings"
  ON bookings FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can view their bookings"
  ON bookings FOR SELECT
  USING (true);

-- Testimonials policies (public read, anyone can create)
CREATE POLICY "Anyone can view testimonials"
  ON testimonials FOR SELECT
  USING (true);

CREATE POLICY "Anyone can create testimonials"
  ON testimonials FOR INSERT
  WITH CHECK (true);

-- Insert sample destinations
INSERT INTO destinations (name, country, description, image_url, price, rating, category, featured) VALUES
('Bali', 'Indonesia', 'Experience paradise on Earth with pristine beaches, ancient temples, and vibrant culture. Bali offers a perfect blend of relaxation and adventure.', 'https://images.pexels.com/photos/2474690/pexels-photo-2474690.jpeg', 1299, 4.8, 'beach', true),
('Paris', 'France', 'The City of Light beckons with its iconic Eiffel Tower, world-class museums, and romantic ambiance. Discover art, fashion, and culinary excellence.', 'https://images.pexels.com/photos/338515/pexels-photo-338515.jpeg', 1899, 4.9, 'city', true),
('Swiss Alps', 'Switzerland', 'Breathtaking mountain vistas, world-renowned skiing, and charming alpine villages. Perfect for adventure seekers and nature lovers alike.', 'https://images.pexels.com/photos/1906795/pexels-photo-1906795.jpeg', 2499, 4.7, 'mountain', true),
('Santorini', 'Greece', 'Stunning sunsets, white-washed buildings, and azure waters. This Greek island paradise offers romance and beauty at every turn.', 'https://images.pexels.com/photos/1285625/pexels-photo-1285625.jpeg', 1699, 4.9, 'beach', true),
('Kyoto', 'Japan', 'Ancient temples, traditional tea houses, and serene gardens. Immerse yourself in Japanese culture and history in this enchanting city.', 'https://images.pexels.com/photos/402028/pexels-photo-402028.jpeg', 1599, 4.8, 'cultural', true),
('Maldives', 'Maldives', 'Overwater bungalows, crystal-clear lagoons, and vibrant coral reefs. The ultimate tropical escape for luxury and relaxation.', 'https://images.pexels.com/photos/3250613/pexels-photo-3250613.jpeg', 2999, 4.9, 'beach', false),
('Rome', 'Italy', 'Walk through history with the Colosseum, Vatican City, and ancient ruins. Indulge in authentic Italian cuisine and timeless architecture.', 'https://images.pexels.com/photos/2064827/pexels-photo-2064827.jpeg', 1499, 4.7, 'cultural', false),
('Iceland', 'Iceland', 'Northern lights, geothermal hot springs, and dramatic landscapes. Experience nature in its most raw and beautiful form.', 'https://images.pexels.com/photos/773594/pexels-photo-773594.jpeg', 2199, 4.8, 'mountain', false);

-- Insert sample testimonials
INSERT INTO testimonials (customer_name, destination_id, rating, comment) 
SELECT 'Sarah Johnson', id, 5, 'Absolutely breathtaking! The beaches were pristine and the culture was fascinating. Best vacation ever!'
FROM destinations WHERE name = 'Bali' LIMIT 1;

INSERT INTO testimonials (customer_name, destination_id, rating, comment)
SELECT 'Michael Chen', id, 5, 'Paris exceeded all expectations. The food, the art, the atmosphere - everything was perfect. Already planning to return!'
FROM destinations WHERE name = 'Paris' LIMIT 1;

INSERT INTO testimonials (customer_name, destination_id, rating, comment)
SELECT 'Emma Wilson', id, 5, 'The Swiss Alps are a dream come true. Stunning views and incredible skiing. A must-visit for any adventure lover.'
FROM destinations WHERE name = 'Swiss Alps' LIMIT 1;